Rails.application.routes.draw do
  root 'xml#index'
end
