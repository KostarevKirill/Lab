# frozen_string_literal: true

require './func.rb'

print 'Enter word: '
word_str = gets.chomp.to_s

puts
puts 'Parent'
t1 = ParentWord.new(word_str)
t2 = ChildWord.new(word_str, word_str.size)
t1.print_word
puts "Returned word: #{t1.return_word}"
puts "Vowel letters: #{t1.count_vowel_letters}"

puts
puts 'Child'
t2.print_word
puts "Returned word: #{t2.return_word}"
puts "Vowel letters: #{t2.count_vowel_letters}"
