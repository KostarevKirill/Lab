# frozen_string_literal: true

require './func.rb'
require 'minitest/autorun'
# Test class
class TestFunc < Minitest::Test
  def test_1
    str_input = 'ASD'
    t1 = MyFile.new(str_input)
    t1.write_file
    t1.create_file
    str_result = t1.out_file
    assert_equal str_input.downcase, str_result
  end
end
