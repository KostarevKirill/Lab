require 'test_helper'

class TwinsControllerTest < ActionDispatch::IntegrationTest
  test "should get user_input" do
    get user_input_path
    assert_response :success
  end

  test 'should get 0 for negative numbers' do
    get user_output_path, params: { user_number: -1 }
    assert_response :success
    assert_nil assigns[:result]
  end

end
