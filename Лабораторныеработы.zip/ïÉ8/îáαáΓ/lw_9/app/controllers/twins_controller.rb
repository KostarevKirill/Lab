class TwinsController < ApplicationController
  def input
    render layout: false
  end

  def view
    number = params[:number].to_i
    @twins = get_twins(number)

    respond_to do |format|
      format.html
      format.json do
        render json: { twins: @twins }
      end
    end
  end

  private

  def get_twins(number)
    prime_numbers = get_prime_numbers(number)
    twins = []
    prime_numbers[0..-2].each_with_index do |num, index|
      next_num = prime_numbers[index + 1]
      twins.push([num, next_num]) if next_num - num == 2
    end
    twins
  end

  def get_prime_numbers(number)
    (number..2 * number).select { |i| prime?(i) }
  end

  def prime?(number)
    (2..Math.sqrt(number).round).each do |i|
      return false if (number % i).zero?
    end
    true
  end
end
