Rails.application.routes.draw do
  get 'twins/input'
  get 'twins/view'
end
