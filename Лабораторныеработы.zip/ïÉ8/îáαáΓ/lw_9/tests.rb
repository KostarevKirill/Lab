require 'selenium-webdriver'

driver = Selenium::WebDriver.for :chrome
driver.navigate.to 'http://localhost:3000/'

text_field = driver.find_element(id: "number")
text_field.send_keys("70")

button = driver.find_element(name: 'Commit')
button.click

expected = [71, 73, 101, 103, 107, 109, 137, 139]

expected.each do |n|
  unless driver.find_element(tag_name: 'body').text.include?(n.to_s)
    puts "Error: #{n} is not in list!"
  end
end

sleep 2
